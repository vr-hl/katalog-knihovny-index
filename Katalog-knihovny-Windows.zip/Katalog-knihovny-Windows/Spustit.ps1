﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$www = Join-Path $root "www"
$katalog = Join-Path $root "katalog.json"
$port = 8787

function Get-LanIp {
  try {
    $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
      Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" })
    $pick = $ips | Where-Object { $_.PrefixOrigin -eq "Dhcp" } | Select-Object -First 1
    if (-not $pick) { $pick = $ips | Select-Object -First 1 }
    if ($pick) { return $pick.IPAddress }
  } catch {}
  return "127.0.0.1"
}

try { & netsh http add urlacl url="http://+:$port/" user="$env:USERDOMAIN\$env:USERNAME" | Out-Null } catch {}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://+:$port/")
try {
  $listener.Start()
} catch {
  Write-Host "Port $port se nepodarilo otevrit. Spustte Spustit.bat pravym tlacitkem jako spravce."
  Write-Host $_.Exception.Message
  Read-Host "Enter"
  exit 1
}

$ip = Get-LanIp
$index = Join-Path $www "index.html"
if (-not (Test-Path $index)) {
  Write-Host "CHYBI soubor:"
  Write-Host $index
  Write-Host "Rozbalte cely zip znovu. Slozka www musi obsahovat index.html."
} else {
  Write-Host "Aplikace nalezena."
}
Write-Host ""
Write-Host "Katalog knihovny bezi."
Write-Host "Na tomto pocitaci:  http://localhost:$port/"
Write-Host "V telefonu zadejte: http://${ip}:$port"
Write-Host "Okno nezavirejte, dokud chcete sdilet katalog s telefonem."
Write-Host ""
Start-Process "http://localhost:$port/"

$mimes = @{
  ".html" = "text/html; charset=utf-8"
  ".js" = "text/javascript; charset=utf-8"
  ".css" = "text/css; charset=utf-8"
  ".json" = "application/json; charset=utf-8"
  ".svg" = "image/svg+xml"
  ".png" = "image/png"
  ".jpg" = "image/jpeg"
  ".jpeg" = "image/jpeg"
  ".webp" = "image/webp"
  ".ico" = "image/x-icon"
  ".webmanifest" = "application/manifest+json"
  ".txt" = "text/plain; charset=utf-8"
}

function Send-Bytes($ctx, $code, $type, $bytes) {
  $ctx.Response.StatusCode = $code
  $ctx.Response.ContentType = $type
  $ctx.Response.Headers.Add("Access-Control-Allow-Origin", "*")
  $ctx.Response.Headers.Add("Access-Control-Allow-Methods", "GET, PUT, POST, OPTIONS")
  $ctx.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
  $ctx.Response.ContentLength64 = $bytes.Length
  $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $ctx.Response.Close()
}

function Send-Text($ctx, $code, $type, $text) {
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
  Send-Bytes $ctx $code $type $bytes
}

$utf8 = New-Object System.Text.UTF8Encoding $false
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
  } catch {
    break
  }
  $req = $ctx.Request
  $path = $req.Url.AbsolutePath
  try {
    if ($req.HttpMethod -eq "OPTIONS") {
      Send-Text $ctx 204 "text/plain" ""
      continue
    }
    if ($path -eq "/api/stav") {
      $nazev = ""
      $zmeneno = ""
      $knih = 0
      if (Test-Path $katalog) {
        try {
          $obj = Get-Content -Raw -Encoding UTF8 $katalog | ConvertFrom-Json
          $nazev = [string]$obj.meta.nazev
          $zmeneno = [string]$obj.meta.zmeneno
          if ($obj.svazky) { $knih = @($obj.svazky).Count }
        } catch {}
      }
      $payload = @{ ok = $true; nazev = $nazev; zmeneno = $zmeneno; knih = $knih; adresa = "http://${ip}:$port" } | ConvertTo-Json -Compress
      Send-Text $ctx 200 "application/json; charset=utf-8" $payload
      continue
    }
    if ($path -eq "/api/cteni" -and $req.HttpMethod -eq "POST") {
      $reader = New-Object System.IO.StreamReader($req.InputStream, $utf8)
      $body = $reader.ReadToEnd()
      $reader.Close()
      $klicSoubor = Join-Path $root "klic.txt"
      if (-not (Test-Path $klicSoubor)) {
        Send-Text $ctx 500 "application/json; charset=utf-8" '{"ok":false,"error":"Vedle Spustit.bat chybi soubor klic.txt s klicem ke cteni."}'
        continue
      }
      $key = (Get-Content -Raw -Encoding UTF8 $klicSoubor).Trim()
      if (-not $key) {
        Send-Text $ctx 500 "application/json; charset=utf-8" '{"ok":false,"error":"Soubor klic.txt je prazdny."}'
        continue
      }
      $client = $null
      try {
        Add-Type -AssemblyName System.Net.Http -ErrorAction SilentlyContinue
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromSeconds(150)
        $msg = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Post, "https://api.x.ai/v1/chat/completions")
        [void]$msg.Headers.TryAddWithoutValidation("Authorization", "Bearer $key")
        $bytes = $utf8.GetBytes($body)
        $content = New-Object System.Net.Http.ByteArrayContent (,$bytes)
        $content.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse("application/json")
        $msg.Content = $content
        $odeslani = $client.SendAsync($msg)
        $odeslani.Wait()
        $resp = $odeslani.Result
        $cteni = $resp.Content.ReadAsStringAsync()
        $cteni.Wait()
        $text = $cteni.Result
        if (-not $text) { $text = '{"ok":false,"error":"Prazdna odpoved cteni."}' }
        Send-Text $ctx ([int]$resp.StatusCode) "application/json; charset=utf-8" $text
      } catch {
        $hlaska = $_.Exception.Message
        if ($_.Exception.InnerException) { $hlaska = $_.Exception.InnerException.Message }
        $bezpecna = ($hlaska -replace '\\','\\\\' -replace '"','\"')
        Send-Text $ctx 502 "application/json; charset=utf-8" "{`"ok`":false,`"error`":`"Cteni z pocitace selhalo. $bezpecna`"}"
      } finally {
        if ($client) { $client.Dispose() }
      }
      continue
    }
    if ($path -eq "/api/katalog" -and $req.HttpMethod -eq "GET") {
      if (-not (Test-Path $katalog)) {
        Send-Text $ctx 404 "application/json; charset=utf-8" '{"ok":false,"error":"Na pocitaci jeste neni katalog."}'
      } else {
        Send-Bytes $ctx 200 "application/json; charset=utf-8" ([System.IO.File]::ReadAllBytes($katalog))
      }
      continue
    }
    if ($path -eq "/api/katalog" -and ($req.HttpMethod -eq "PUT" -or $req.HttpMethod -eq "POST")) {
      $reader = New-Object System.IO.StreamReader($req.InputStream, $utf8)
      $body = $reader.ReadToEnd()
      $reader.Close()
      [System.IO.File]::WriteAllText($katalog, $body, $utf8)
      Send-Text $ctx 200 "application/json; charset=utf-8" '{"ok":true}'
      continue
    }
    $rel = [Uri]::UnescapeDataString($path.TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($rel)) { $rel = "index.html" }
    $rel = $rel.Replace("/", [IO.Path]::DirectorySeparatorChar)
    $file = Join-Path $www $rel
    $wwwFull = [IO.Path]::GetFullPath($www)
    $fileFull = [IO.Path]::GetFullPath($file)
    if (-not $fileFull.StartsWith($wwwFull) -or -not (Test-Path $fileFull) -or (Get-Item $fileFull).PSIsContainer) {
      $fileFull = Join-Path $www "index.html"
    }
    if (-not (Test-Path $fileFull)) {
      $msg = "<!DOCTYPE html><meta charset=utf-8><title>Chybi aplikace</title><body style='font-family:sans-serif;background:#EAEBE5;padding:2rem'><h1>Aplikace se nenasla</h1><p>Vedle souboru Spustit.bat musi byt slozka www a v ni index.html.</p><p>Zavrete toto okno, rozbalte cely zip znovu a spustte Spustit.bat z nove slozky.</p></body>"
      Send-Text $ctx 404 "text/html; charset=utf-8" $msg
      continue
    }
    $ext = [IO.Path]::GetExtension($fileFull).ToLower()
    $type = $mimes[$ext]
    if (-not $type) { $type = "application/octet-stream" }
    Send-Bytes $ctx 200 $type ([System.IO.File]::ReadAllBytes($fileFull))
  } catch {
    try { Send-Text $ctx 500 "text/plain; charset=utf-8" $_.Exception.Message } catch {}
  }
}
